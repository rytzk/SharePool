Set-Location $HOME
Set-PSReadLineOption -EditMode Emacs

## Aliases
Set-Alias which Get-Command

$ORIG_PATH=$Env:PATH

## Neovim and SpaceVim
$NVIM_BIN = "$PSHOME\..\..\opt\Neovim\bin\nvim-qt.exe"
$SVIM_INI = "$HOME\.config\SpaceVim\init.vim"
if ((Test-Path -Path $NVIM_BIN) -eq "True"){
  if ((Test-Path -Path $SVIM_INI) -eq "True"){
    function SpaceVim {
      Push-Location $HOME
      Start-Process -FilePath "$NVIM_BIN" -ArgumentList "-- -u $SVIM_INI"
      Pop-Location}
    Set-Alias svim SpaceVim
  }else{Remove-Variable -Name SVIM_INI}
}else{Remove-Variable -Name NVIM_BIN}


## Vim Kaoriya
$KVIM_DIR = "$PSHOME\..\..\opt\VimKaoriya"
if ((Test-Path $KVIM_DIR) -eq "True"){
  Set-Item Env:Path "$KVIM_DIR;$Env:Path"
}else{Remove-Variable -Name KVIM_DIR}


## Emacs
$EMACS_DIR = "$PSHOME\..\..\opt\Emacs"
if ((Test-Path $EMACS_DIR) -eq "True"){
  Set-Item Env:Path "$EMACS_DIR\bin;$Env:Path"
  Set-Alias emacs runemacs.exe
}else{Remove-Variable -Name EMACS_DIR}


### Python3.10
#$PYTHON_DIR = "$PSHOME\..\..\opt\Python3"
#if ((Test-Path $PYTHON_DIR) -eq "True"){
#  Set-Item Env:Path "$PYTHON_DIR;$PYTHON_DIR\Scripts;$Env:Path"
#  $PYENV_ROOT = "$HOME\.pyenv"
#  if ((Test-Path $PYENV_ROOT) -eq "True"){
#    Set-Item Env:Path "$PYENV_ROOT\pyenv-win\bin;$PYENV_ROOT\pyenv-win\shims;$Env:Path"
#  }else{Remove-Variable -Name PYENV_ROOT}
#}else{Remove-Variable -Name PYTHON_DIR}
#$PYSCRPT_DIR = "$HOME\AppData\Roaming\Python\Scripts"
#if ((Test-Path $PYSCRPT_DIR) -eq "True"){
#  Set-Item Env:Path "$PYSCRPT_DIR;$Env:Path"
#  Set-Alias emacs runemacs.exe
#}else{Remove-Variable -Name PYSCRPT_DIR}

## Miniconda3
$CONDA_DIR = "$PSHOME\..\..\opt\Conda"
if ((Test-Path $Conda_DIR) -eq "True"){
  $ENV:Path+=";$CONDA_DIR;$CONDA_DIR\Scripts"
  Set-Item Env:Path "$CONDA_DIR;$CONDA_DIR\Scripts;$Env:Path"
}else{Remove-Variable -Name CONDA_DIR}

$PYSCRPT_DIR = "$HOME\AppData\Roaming\Python\Scripts"
if ((Test-Path $PYSCRPT_DIR) -eq "True"){
  Set-Item Env:Path "$PYSCRPT_DIR;$Env:Path"
}else{Remove-Variable -Name PYSCRPT_DIR}

$PYENV_DIR = "$PSHOME\..\..\opt\Conda\Lib\site-packages\pyenv-win"
if ((Test-Path $PYENV_DIR) -eq "True"){
  $PYENV = "$PYENV_DIR"
  $PYENV_ROOT = "$PYENV_DIR"
  $PYENV_HOME = "$PYENV_DIR"
  Set-Item Env:PYENV "$PYENV_DIR"
  Set-Item Env:PYENV_ROOT "$PYENV_DIR"
  Set-Item Env:PYENV_HOME "$PYENV_DIR"
  Set-Item Env:path "$PYENV_DIR\bin;$PYENV_DIR\shims;$Env:Path"
}else{Remove-Variable -Name PYENV_DIR}


### OpenJDK17
#$JAVA_HOME = "$PSHOME\..\..\opt\OpenJDK17"
#if ((Test-Path $JAVA_HOME) -eq "True"){
#  Set-Item Env:Path "$JAVA_HOME\bin;$Env:Path"
#}else{Remove-Variable -Name JAVA_HOME}


## 7zip
$SEVENZ_DIR = "$PSHOME\..\..\opt\7zip"
if ((Test-Path $SEVENZ_DIR) -eq "True"){
  Set-Item Env:Path "$SEVENZ_DIR;$Env:Path"
}else{Remove-Variable -Name SEVENZ_DIR}


## QEMU
$QEMU_DIR= "$PSHOME\..\..\opt\Qemu"
if ((Test-Path $QEMU_DIR) -eq "True"){
  Set-Item Env:Path "$QEMU_DIR;$Env:Path"
}else{Remove-Variable -Name QEMU_DIR}


## Misc Binaries
$BIN_DIR = "$PSHOME\..\..\bin"
if ((Test-Path -Path $BIN_DIR) -eq "True"){
  Set-Item Env:Path "$BIN_DIR;$Env:Path"
}else{Remove-Variable -Name BIN_DIR}

