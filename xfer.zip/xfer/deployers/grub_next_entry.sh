#!/system/bin/sh

partition=sda5
number=3

[ $1 ] && number=$1

[ ! -d /mnt/$partition ] && mkdir /mnt/$partition
mount -t vfat /dev/block/$partition /mnt/$partition

sed -Ei -e "s/(next_entry)\=[0-9]*/\1=$number/g" /mnt/$partition/grub/grubenv

umount /mnt/$partition
rmdir /mnt/$partition

