Write-Output 'Import-Module $PROFILE.CurrentUserCurrentHost' >> $CmderUserProfilePath

cd $Env:USERPROFILE
git config --global http.sslcainfo $Env:CMDER_ROOT\vendor\git-for-windows\mingw64\ssl\certs\ca-bundle.crt
git clone https://github.com/SpaceVim/SpaceVim.git "$Env:USERPROFILE\.config\SpaceVim"
#git clone https://github.com/pyenv-win/pyenv-win.git "$Env:USERPROFILE\.pyenv"
git clone https://github.com/syl20bnr/spacemacs.git "$Env:USERPROFILE\.emacs.d"

git config --global credential.helper cache
git config --global user.email tzkry012@gmail.com
git config --global user.name rytzk
git clone https://github.com/rytzk/dotfiles.git "$Env:USERPROFILE\dotfiles"
@(
".bashrc.d"
".SpaceVim.d"
"Documents"
".bash_profile"
".vimrc"
) | %{Copy-Item -Recurse -Force -Path $Env:USERPROFILE\dotfiles\$_ -Destination .\}

#Invoke-WebRequest -UseBasicParsing -Uri https://repo.anaconda.com/miniconda/Miniconda3-latest-Windows-x86_64.exe -OutFile Downloads\Miniconda.exe
#.\Downloads\Miniconda.exe /S /InstallationType=JustMe /AddToPath=0 /RegisterPython=0 /NoRegistry=1 /D=$Env:USERPROFILE\.pyenv\pyenv-win\versions\Miniconda3\
#$ENV:Path+=";$Env:USERPROFILE\.pyenv\pyenv-win\versions\Miniconda3\;$Env:USERPROFILE\.pyenv\pyenv-win\versions\Miniconda3\Scripts"
