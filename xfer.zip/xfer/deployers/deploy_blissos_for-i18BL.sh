#!/bin/bash

[[ $(id -u) -ne 0 ]] && \
  echo "Only superuser can run this script." && sleep 3 && exit
[[ ! $(ls *.iso 2>/dev/null) ]] && \
  echo "Download ISO file first." && exit

# Bliss OS ISO file
# cf: https://drive.google.com/file/d/10Ijbrblp-dAAIjLE1FRAiEMA1vSwuOis/view?usp=sharing
iso_file=$(ls -1 *.iso | head -n1)

# Partitions
andr_part=/dev/sda7

# Mount points
andr_mnt=/android
iso_mnt=/mnt/iso
sfs_mnt=/mnt/sfs
img_mnt=/mnt/img

# Microcode
ucode=/boot/intel-ucode.img

# Prepare directories
[[ ! -d /andr_mnt ]] && \
  mkdir $andr_mnt
mkdir $iso_mnt $sfs_mnt $img_mnt 

# Mount
[[ "$(mount | grep $andr_part | cut -f1,3  -d' ')" != "${andr_part} ${andr_mnt}" ]] && \
  mount $andr_part $andr_mnt
mount $iso_file $iso_mnt
mount ${iso_mnt}/system.sfs $sfs_mnt

# -------
pushd $andr_mnt
# -------

# Copy system files
[[ -f kernel || -f initrd.img || -f ramdisk.img || -f system.img || -f system.sfs || -d system || -d data || -d mod ]] && \
  echo "Files are already exist." && sleep 3 && exit

cp -n ${iso_mnt}/{kernel,initrd.img,ramdisk.img,gearlock} $andr_mnt
  echo "Copying system..."
cp -n ${sfs_mnt}/system.img $andr_mnt
cp -n $ucode $andr_mnt
mkdir ${andr_mnt}/data

# Modify build.prop
mount ${andr_mnt}/system.img $img_mnt
sed -Ei -e "s/poweroff.doubleclick=.*//g" -e "s/sleep.earlysuspend=.*//g" ${img_mnt}/build.prop
echo "poweroff.doubleclick=0">>${img_mnt}/build.prop
echo "sleep.earlysuspend=2">>${img_mnt}/build.prop
umount $img_mnt

# -------
popd
# -------

# Magisk
[[ ! -d mod ]] && \
  mkdir mod
cd mod
git clone https://github.com/shakalaca/MagiskOnEmulator.git

[[ ! -d tmp ]] && \
  mkdir tmp
curl -Lso tmp/magisk.zip https://github.com/$(curl -Ls https://github.com/topjohnwu/Magisk/releases/latest | grep -Po "a href=.\K.+Magisk\-.+?\.apk")

cp ${andr_mnt}/initrd.img tmp/initrd.img.gz
cp ${andr_mnt}/ramdisk.img tmp/ramdisk.img.gz
cp MagiskOnEmulator/{process.sh,initrd.patch,busybox} tmp/
dos2unix tmp/process.sh

mkdir ${andr_mnt}/gearload
[[ ! -d gearload ]] && mkdir gearload
find .. -name *.gxp | xargs -i cp -n {} gearload/
cp -rn gearload/* ${andr_mnt}/gearload
cp -rn tmp ${andr_mnt}/gearload/
cd ..
[[ -f gearlock ]] && cp -n gearlock ${andr_mnt}/gearload/tmp/
[[ -f grub_next_entry.sh ]] &&  cp -n grub_next_entry.sh ${andr_mnt}/gearload/tmp/
rm -rf mod

cat <<'EOF' >>${andr_mnt}/gearload/patch_magisk.sh
#!/bin/sh

cp -rf /mnt/gearload/tmp/* /data/local/tmp/
mv /data/local/tmp/gearlock /data/
chmod +x /data/local/tmp/process.sh
/data/local/tmp/process.sh /data/local/tmp $1

echo "Mounting system partition" && sleep 3
mkdir /mnt/sda7
mount /dev/block/sda7 /mnt/sda7

echo "Moving patched initrd.img" && sleep 3
mv /mnt/sda7/initrd.img /mnt/sda7/initrd.img.bak
mv /mnt/sda7/ramdisk.img /mnt/sda7/ramdisk.img.bak
echo "...Done"
echo "Moving patched ramdisk.img" && sleep 3
mv /data/local/tmp/initrd.img /mnt/sda7/
mv /data/local/tmp/ramdisk.img /mnt/sda7/
echo "...Done"
rm -f /data/local/tmp/ramdisk.orig
mv /system/xbin/su /system/xbin/su.orig
umount /mnt/sda7
rmdir /mnt/sda7
mkdir /data/adb/post-fs-data.d
mv /data/local/tmp/grub_next_entry.sh /data/adb/post-fs-data.d/
sh /data/adb/post-fs-data.d/grub_next_entry.sh
echo "Complete! Please restart system."
EOF
chmod +x ${andr_mnt}/gearload/patch_magisk.sh


umount $img_mnt && rmdir $img_mnt
umount $sfs_mnt && rmdir $sfs_mnt
umount $iso_mnt && rmdir $iso_mnt

