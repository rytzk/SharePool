# Cmder構築

$ProgressPreference = 'SilentlyContinue'
$CMDER_ROOT = "cmder"

function Fetch-GithubLatestReleaseFile {
  param ($Repo,$Hint)
  $ProgressPreference = 'SilentlyContinue'
  $Base = "https://github.com"
  $LatestReleases = "releases/latest"
  $LatestPage = Invoke-WebRequest -Uri "$Base/$Repo/$LatestReleases"
  $ReleaseFilePath = $LatestPage.Links | Where-Object {$_.href -like "*$Hint"} | Select-Object -ExpandProperty href -First 1
  $ReleaseFileURL = "https://github.com/$ReleaseFilePath"
  $FileName = $ReleaseFileURL.split("/")[-1]
  if ((Test-Path $FileName) -eq $false){ 
    Invoke-WebRequest -UseBasicParsing -Uri $ReleaseFileURL -OutFile $FileName}
  $ProgressPreference = 'Continue'
  Return $FileName
}

function Fetch-LastFile {
  param ($BaseUrl,$Hint)
  $ProgressPreference = 'SilentlyContinue'
  $FileName = ((Invoke-WebRequest -UseBasicParsing -Uri $BaseUrl).links | Where-Object {$_.href -like "*$Hint"} | Select-Object -ExpandProperty href -Last 1)
  if ((Test-Path $FileName) -eq $false){ 
    Invoke-WebRequest -UseBasicParsing -Uri $BaseUrl/$FileName -OutFile $FileName}
  $ProgressPreference = 'Continue'
  Return $FileName
}

New-Item -ItemType Directory _Done | Out-Null

Invoke-WebRequest -UseBasicParsing -Uri "https://github.com/rytzk/deployers/raw/main/7z.zip" -OutFile 7z.zip
Expand-Archive -Path 7z.zip -DestinationPath .\
Remove-Item -Force 7z.zip

$repo = "cmderdev/cmder"
$hint = "cmder_mini.zip"
$file = [string](Fetch-GithubLatestReleaseFile -Repo $repo -Hint $hint)
.\7z.exe x -o"$CMDER_ROOT" "$file"
Move-Item -Path "$file" -Destination ".\_Done\"

cd $CMDER_ROOT

# ホームフォルダ構造
@(
"home\.bashrc.d"
"home\.cache"
"home\.config\xdg"
"home\.emacs.d"
"home\.local\share\fonts"
"home\.local\state"
"home\.profile.d"
"home\.run\user"
"home\AppData\Local"
"home\AppData\Roaming\Python\Scripts"
"home\AppData\ProgramData"
"home\AppData\ProgramFiles\CommonFiles"
"home\AppData\Temp"
"home\Desktop"
"home\Documents\Music"
"home\Documents\Pictures"
"home\Documents\Videos"
"home\Documents\Templates"
"home\Documents\Contacts"
"home\Documents\Favorites"
"home\Documents\Links"
"home\Documents\Searches"
"home\Documents\SavedGames"
"home\Downloads"
"home\Common"
"home\works"
) | %{New-Item -ItemType Directory -Force $_} | Out-Null

cd ..

$repo = "git-for-windows/git"
$hint = "MinGit-*-busybox-64-bit.zip"
$dir  = "git-for-windows"
$file = [string](Fetch-GithubLatestReleaseFile -Repo $repo -Hint $hint)
.\7z.exe x -o"$dir" "$file"
Move-Item -Path "$dir" -Destination ".\$CMDER_ROOT\vendor\"
Move-Item -Path "$file" -Destination ".\_Done\"


$repo = "PowerShell/Powershell"
$hint = "PowerShell-*-win-x64.zip"
$dir  = "PowerShell"
$file = [string](Fetch-GithubLatestReleaseFile -Repo $repo -Hint $hint)
.\7z.exe x -o"$dir" "$file"
Move-Item -Path "$dir" -Destination ".\$CMDER_ROOT\vendor\"
Move-Item -Path "$file" -Destination ".\_Done\"


$repo = "neovim/neovim"
$hint = "nvim-win64.zip"
$file = [string](Fetch-GithubLatestReleaseFile -Repo $repo -Hint $hint)
.\7z.exe x -o"temp" "$file"
Move-Item -Path ".\temp\Neovim" -Destination ".\$CMDER_ROOT\opt\"
Remove-Item ".\temp"
Move-Item -Path "$file" -Destination ".\_Done\"


$repo = "koron/vim-kaoriya"
$hint = "vim82-kaoriya-win64-*[0-9].zip"
$dir  = "VimKaoriya"
$file = [string](Fetch-GithubLatestReleaseFile -Repo $repo -Hint $hint)
.\7z.exe x -o"temp" "$file"
Move-Item -Path (".\temp\" + (Get-ChildItem temp | Select-Object -ExpandProperty Name) + "\") -Destination ".\$CMDER_ROOT\opt\$dir"
Remove-Item -Path "temp" -Recurse -Force
Move-Item -Path "$file" -Destination ".\_Done\"


$base = "http://unifoundry.com/pub/unifont/"
$version = (Invoke-WebRequest -UseBasicParsing -Uri $base).links | Select-Object -expandProperty href -Last 1
$build = $base + $version + "font-builds/"
$latest = (Invoke-WebRequest -UseBasicParsing -Uri $build).links | Where-Object {$_.href -like "*unifont_jp*.ttf"} | Select-Object -ExpandProperty href
Invoke-WebRequest -UseBasicParsing -Uri ($build + $latest) -OutFile "$CMDER_ROOT\vendor\conemu-maximus5\ConEmu\unifont_jp.ttf"


$repo = "jgm/pandoc"
$hint = "pandoc-*-windows-x86_64.zip"
$file = [string](Fetch-GithubLatestReleaseFile -Repo $repo -Hint $hint)
.\7z.exe e -o"temp" "$file"
Move-Item -Path ".\temp\pandoc.exe" -Destination ".\$CMDER_ROOT\bin\"
Remove-Item -Path "temp" -Recurse -Force
Move-Item -Path "$file" -Destination ".\_Done\"


$repo = "asciidoctor/asciidoctor.js"
$hint = "asciidoctor-win.exe"
$file = [string](Fetch-GithubLatestReleaseFile -Repo $repo -Hint $hint)
Move-Item -Path "$file" -Destination "$CMDER_ROOT\bin\"


$repo = "sclevine/yj"
$hint = "yj.exe"
$file = [string](Fetch-GithubLatestReleaseFile -Repo $repo -Hint $hint)
Move-Item -Path "$file" -Destination "$CMDER_ROOT\bin\"


$repo = "rclone/rclone"
$hint = "rclone-*-windows-amd64.zip"
$file = [string](Fetch-GithubLatestReleaseFile -Repo $repo -Hint $hint)
.\7z.exe e -o"temp" "$file"
Move-Item -Path ".\temp\rclone.exe" -Destination ".\$CMDER_ROOT\bin\"
Remove-Item -Path "temp" -Recurse -Force
Move-Item -Path "$file" -Destination ".\_Done\"


$repo = "sharkdp/fd"
$hint = "fd-*-x86_64-pc-windows-gnu.zip"
$file = [string](Fetch-GithubLatestReleaseFile -Repo $repo -Hint $hint)
.\7z.exe e -o"temp" "$file"
Move-Item -Path ".\temp\*" -Destination ".\$CMDER_ROOT\bin\"
Remove-Item -Path "temp" -Recurse -Force
Move-Item -Path "$file" -Destination ".\_Done\"


$repo = "tadashi-aikawa/gowl"
$hint = "gowl-*-x86_64-windows.zip"
$file = [string](Fetch-GithubLatestReleaseFile -Repo $repo -Hint $hint)
.\7z.exe e -o"temp" "$file"
Move-Item -Path ".\temp\gowl.exe" -Destination ".\$CMDER_ROOT\bin\"
Remove-Item -Path "temp" -Recurse -Force
Move-Item -Path "$file" -Destination ".\_Done\"


$repo = "junegunn/fzf"
$hint = "fzf-*-windows_amd64.zip"
$file = [string](Fetch-GithubLatestReleaseFile -Repo $repo -Hint $hint)
.\7z.exe e -o"temp" "$file"
Move-Item -Path ".\temp\fzf.exe" -Destination ".\$CMDER_ROOT\bin\"
Remove-Item -Path "temp" -Recurse -Force
Move-Item -Path "$file" -Destination ".\_Done\"


$repo = "msys2/msys2-installer"
$hint = "msys2-base-x86_64-*.sfx.exe"
$dir  = "Msys2"
$file = [string](Fetch-GithubLatestReleaseFile -Repo $repo -Hint $hint)
.\7z x "$file"
Rename-Item "msys64" "$dir"
Move-Item -Path "$dir" -Destination ".\$CMDER_ROOT\vendor\"
Move-Item -Path "$file" -Destination ".\_Done\"


$base = "http://mirrors.ibiblio.org/gnu/emacs/windows/emacs-27/"
$hint = "emacs-*-x86_64.zip"
$dir  = "Emacs"
$file = [string](Fetch-LastFile -BaseUrl $base -Hint $hint)
.\7z.exe x -o"$dir" "$file"
Move-Item -Path "$dir" -Destination ".\$CMDER_ROOT\opt\"
Move-Item -Path "$file" -Destination ".\_Done\"


$base = "https://eternallybored.org/misc/wget/releases/"
$hint = "wget-*-win64.zip"
$file = [string](Fetch-LastFile -BaseUrl $base -Hint $hint)
.\7z.exe e -o"temp" "$file"
Move-Item -Path .\temp\wget.exe -Destination ".\$CMDER_ROOT\bin"
Remove-Item -Path "temp" -Recurse -Force
Move-Item -Path "$file" -Destination ".\_Done\"


# $base = "https://eternallybored.org/misc/netcat/"
# $hint = "netcat-*.zip"
# $file = [string](Fetch-LastFile -BaseUrl $base -Hint $hint)
# .\7z.exe e -o"temp""$file"
# Move-Item -Path .\temp\nc64.exe -Destination ".\$CMDER_ROOT\bin\"
# Remove-Item -Path "temp" -Recurse -Force
# Move-Item -Path "$file" -Destination ".\_Done\"


$base = "https://eternallybored.org/misc/pciutils/releases/"
$hint = "pciutils-*-win64.zip"
$file = [string](Fetch-LastFile -BaseUrl $base -Hint $hint)
.\7z.exe e -o"temp" "$file"
Move-Item -Path ".\temp\*" -Destination ".\$CMDER_ROOT\bin\"
Remove-Item -Path "temp" -Recurse -Force
Move-Item -Path "$file" -Destination ".\_Done\"


$repo = "mcmilk/7-Zip-zstd"
$hint = "7z*x64.exe"
$dir  = "7zip"
$file = [string](Fetch-GithubLatestReleaseFile -Repo $repo -Hint $hint)
.\7z.exe x -o"$dir" "$file"
Move-Item -Path "$file" -Destination ".\_Done\"

$hint = "Codecs-x64.7z"
$file = [string](Fetch-GithubLatestReleaseFile -Repo $repo -Hint $hint)
.\7z.exe x -o"$dir\Codecs" "$file"
Move-Item -Path .\7zip -Destination .\$CMDER_ROOT\opt\
Move-Item -Path "$file" -Destination ".\_Done\"


$base = "https://qemu.weilnetz.de/w64/"
$hint = "qemu-w64-setup-*.exe"
$dir  = "Qemu"
$file = [string](Fetch-LastFile -BaseUrl $base -Hint $hint)
Invoke-WebRequest -Uri $base$file -OutFile "$file"
.\7z.exe x -o"$dir" "$file"
Move-Item -Path "$dir" -Destination ".\$CMDER_ROOT\opt\"
Move-Item -Path "$file" -Destination ".\_Done\"

$base = "https://repo.anaconda.com/miniconda/"
$file = "Miniconda3-latest-Windows-x86_64.exe"
$dir = "Conda"
Invoke-WebRequest -Uri $base$file -OutFile $file
Start-Process -Path $file -ArgumentList "/S /InstallationType=JustMe /AddToPath=0 /RegisterPython=0 /NoRegistry=1 /D=$PWD\$CMDER_ROOT\opt\$dir"

Remove-Item -Force 7z.dll
Remove-Item -Force 7z.exe

Invoke-WebRequest -Uri "https://raw.githubusercontent.com/rytzk/dotfiles/main/user-ConEmu.xml" -OutFile $CMDER_ROOT\config\user-ConEmu.xml

$ProgressPreference = 'Continue'


